/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cornet_desktop.presenter;

import cornet_desktop.database.DBAction;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ilham
 */
public class CostEstimationPresenter extends DBAction{
    private List<String> tipeTower = new ArrayList<>();
    private List<String> classPondasi = new ArrayList<>();
    
    public void loadTipeTower(){
        try {
            String namaKolom = "tipe_tower";
            ResultSet rs = getWithoudDuplicateData(namaKolom, "material_tower");
            while(rs.next()){
                String tipe = rs.getString(namaKolom);
                tipeTower.add(tipe);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CostEstimationPresenter.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void loadClassPondasi(){
        try {
            String namaKolom = "class";
            ResultSet rs = getWithoudDuplicateData(namaKolom, "pondasi_tower");
            while(rs.next()){
                String pondasi = rs.getString(namaKolom);
                classPondasi.add(pondasi);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CostEstimationPresenter.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public double getHargaPondasi(String tipeTower, String classPondasi){
        double hargaPondasi = 0.0;
        String namaKolom = "harga_pondasi";
        try {
            ResultSet rs = getSpecificColumn(namaKolom, "pondasi_tower", " WHERE tipe='" + tipeTower + "' AND class='" + classPondasi +"'");
            while(rs.next()){
                hargaPondasi = Double.parseDouble(rs.getString(namaKolom));
            }
            return hargaPondasi;
        } catch (SQLException ex) {
            Logger.getLogger(CostEstimationPresenter.class.getName()).log(Level.SEVERE, null, ex);
        }
        return hargaPondasi;
    }
    
    public double getHargaTower(String tipeTower, String basisTower){
        double hargaTower = 0.0;
        String namaKolom = "harga_permenperin";
        try {
            ResultSet rs = getSpecificColumn(namaKolom, "material_tower", " WHERE tipe_tower='" + tipeTower + "' AND basis='BASIS " + basisTower +"'");
            while(rs.next()){
                hargaTower = Double.parseDouble(rs.getString(namaKolom));
            }
            return hargaTower;
        } catch (SQLException ex) {
            Logger.getLogger(CostEstimationPresenter.class.getName()).log(Level.SEVERE, null, ex);
        }
        return hargaTower;
    }

    public List<String> getTipeTower() {
        return tipeTower;
    }

    public List<String> getClassPondasi() {
        return classPondasi;
    }
    
}
