package cornet_desktop;


public class Cornet_desktop {
    
    public static void main(String[] args) {
        LogInCornet lc = new LogInCornet();
        lc.setVisible(true);
    }
    
}